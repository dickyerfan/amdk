#
# TABLE STRUCTURE FOR: absen_karyawan_produksi
#

DROP TABLE IF EXISTS `absen_karyawan_produksi`;

CREATE TABLE `absen_karyawan_produksi` (
  `id_absen_karprod` int(11) NOT NULL AUTO_INCREMENT,
  `id_karyawan_produksi` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status_absen` varchar(50) NOT NULL,
  `tgl_input_absen` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_absen_karprod`),
  KEY `id_karyawan_produksi` (`id_karyawan_produksi`),
  CONSTRAINT `absen_karyawan_produksi_ibfk_1` FOREIGN KEY (`id_karyawan_produksi`) REFERENCES `karyawan_produksi` (`id_karyawan_produksi`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4;

INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (1, 1, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (2, 2, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (3, 5, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (4, 6, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (5, 7, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (6, 9, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (7, 10, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (8, 11, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (9, 12, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (10, 13, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (11, 14, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (12, 15, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (13, 16, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (14, 17, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (15, 18, '2023-09-01', '1', '2023-10-23 07:14:45');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (16, 1, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (17, 7, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (18, 10, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (19, 12, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (20, 13, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (21, 14, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (22, 15, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (23, 18, '2023-09-02', '1', '2023-10-23 07:36:08');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (24, 2, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (25, 4, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (26, 5, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (27, 6, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (28, 7, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (29, 9, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (30, 10, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (31, 11, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (32, 12, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (33, 13, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (34, 14, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (35, 15, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (36, 17, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (37, 18, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (38, 19, '2023-09-04', '1', '2023-10-23 07:40:17');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (39, 1, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (40, 2, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (41, 4, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (42, 5, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (43, 6, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (44, 7, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (45, 9, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (46, 10, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (47, 11, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (48, 12, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (49, 13, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (50, 14, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (51, 15, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (52, 17, '2023-09-05', '1', '2023-10-23 12:00:36');
INSERT INTO `absen_karyawan_produksi` (`id_absen_karprod`, `id_karyawan_produksi`, `tanggal`, `status_absen`, `tgl_input_absen`) VALUES (53, 18, '2023-09-05', '1', '2023-10-23 12:00:36');


#
# TABLE STRUCTURE FOR: baku_produksi
#

DROP TABLE IF EXISTS `baku_produksi`;

CREATE TABLE `baku_produksi` (
  `id_keluar_baku` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_keluar` int(10) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `status_keluar` int(1) NOT NULL DEFAULT 0,
  `status_tolak` int(1) NOT NULL DEFAULT 1,
  `status_produksi` int(1) NOT NULL DEFAULT 1,
  `input_status_keluar` varchar(50) NOT NULL,
  `tgl_input_keluar` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_keluar_gd` varchar(50) NOT NULL,
  PRIMARY KEY (`id_keluar_baku`),
  KEY `id_barang_baku` (`id_barang_baku`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (1, 8, 400, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:04:49', '2023-09-01.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (2, 4, 1000, '2023-09-04', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:05:32', '2023-09-04.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (3, 7, 96000, '2023-09-04', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:05:55', '2023-09-04.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (4, 10, 500, '2023-09-05', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:08:09', '2023-09-05.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (5, 8, 400, '2023-09-06', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:09:09', '2023-10-06.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (6, 8, 400, '2023-09-07', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:10:10', '2023-09-07.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (7, 7, 96000, '2023-09-11', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:10:51', '2023-09-11.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (8, 6, 144, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:16:13', '2023-09-11.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (9, 8, 240, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:17:52', '2023-09-12.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (10, 10, 200, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:18:13', '2023-09-12.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (11, 3, 1000, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:19:20', '2023-09-13.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (12, 7, 96000, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:46:31', '2023-09-13.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (13, 8, 600, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:46:50', '2023-09-13.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (14, 8, 500, '2023-09-14', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:47:59', '2023-09-14.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (15, 8, 400, '2023-09-15', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:48:39', '2023-09-15.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (16, 8, 500, '2023-09-18', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:49:36', '2023-09-18.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (17, 10, 500, '2023-09-20', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:50:09', '2023-09-20.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (18, 8, 500, '2023-09-21', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:51:03', '2023-09-21.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (19, 4, 1000, '2023-09-22', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:52:02', '2023-09-22.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (20, 3, 1000, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:55:21', '2023-09-26.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (21, 7, 96000, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:55:48', '2023-09-26.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (22, 8, 500, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:56:16', '2023-09-26.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (23, 10, 500, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:56:32', '2023-09-26.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (24, 8, 500, '2023-09-27', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:57:29', '2023-09-27.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (25, 8, 400, '2023-09-28', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:04', '2023-09-28.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (26, 8, 200, '2023-09-29', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:28', '2023-09-29.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (27, 10, 200, '2023-09-29', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:44', '2023-09-29.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (57, 11, 200, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:20:18', '2023-09-01.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (58, 24, 1080, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:27:11', '2023-09-01.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (59, 28, 385, '2023-09-01', 1, 1, 0, 'Muh Abd Cholil', '2023-10-24 10:30:57', '2023-09-01.jpg');
INSERT INTO `baku_produksi` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (60, 37, 30720, '2023-09-01', 1, 1, 0, 'Muh Abd Cholil', '2023-10-24 10:34:54', '2023-09-01.jpg');


#
# TABLE STRUCTURE FOR: barang_baku
#

DROP TABLE IF EXISTS `barang_baku`;

CREATE TABLE `barang_baku` (
  `id_barang_baku` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang_baku` varchar(50) NOT NULL,
  `id_satuan` int(11) NOT NULL,
  `id_jenis_barang` int(11) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `status_barang_baku` int(1) NOT NULL DEFAULT 1,
  `tgl_input` datetime NOT NULL DEFAULT current_timestamp(),
  `input_barang_baku` varchar(50) NOT NULL,
  PRIMARY KEY (`id_barang_baku`),
  KEY `id_satuan` (`id_satuan`),
  KEY `id_jenis_barang` (`id_jenis_barang`),
  CONSTRAINT `barang_baku_ibfk_2` FOREIGN KEY (`id_satuan`) REFERENCES `satuan` (`id_satuan`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (1, 'galon baru', 1, 1, 'gal', 1, '2023-09-30 21:26:54', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (2, 'tisu galon', 1, 1, 'tig', 1, '2023-09-30 21:28:29', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (3, 'segel galon', 1, 1, 'seg', 1, '2023-09-30 21:35:29', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (4, 'tutup galon', 1, 1, 'tug', 1, '2023-09-30 21:36:00', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (5, 'stiker galon', 2, 1, 'stg', 1, '2023-09-30 21:39:20', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (6, 'isolasi', 5, 2, 'iso', 1, '2023-09-30 21:39:56', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (7, 'sedotan', 1, 2, 'sed', 1, '2023-09-30 21:40:21', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (8, 'kardus gelas ijen', 1, 2, 'kgi', 1, '2023-09-30 21:41:56', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (9, 'kardus gelas ijen merah', 1, 2, 'kgim', 1, '2023-09-30 21:42:39', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (10, 'kardus gelas genggong', 1, 2, 'kgg', 1, '2023-09-30 21:43:07', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (11, 'Kardus Gelas An Nujum', 1, 2, 'kgn', 1, '2023-10-24 08:15:55', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (12, 'Kardus Gelas SyubbanQ', 1, 2, 'kgs', 1, '2023-10-24 08:34:27', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (13, 'Kardus Gelas Amalis', 1, 2, 'kga', 1, '2023-10-24 08:47:13', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (14, 'Lit Cup Ijen  8 line', 1, 2, 'lci8', 1, '2023-10-24 08:48:37', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (15, 'Lit Cup Ijen  4 line', 1, 2, 'lci4', 1, '2023-10-24 08:50:33', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (16, 'Lit Cup Ijen  2 line', 1, 2, 'lci2', 1, '2023-10-24 08:50:46', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (17, 'Lit Cup Genggong 8 line', 1, 3, 'lcg8', 1, '2023-10-24 08:51:20', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (18, 'Lit Cup Genggong 4 line', 1, 3, 'lcg4', 1, '2023-10-24 08:51:37', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (19, 'Lit Cup An Nujum 8 line', 1, 4, 'lca8', 1, '2023-10-24 08:52:09', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (20, 'Lit Cup SyubbanQ 8 line', 1, 5, 'lcs8', 1, '2023-10-24 08:52:39', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (21, 'Lit Cup SyubbanQ 4 line', 1, 5, 'lcs4', 1, '2023-10-24 08:53:01', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (22, 'Lit Cup Amalis 4 line', 1, 6, 'lcam4', 1, '2023-10-24 08:53:34', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (23, 'Lit Cup Fatayat 2 line', 1, 2, 'lcf2', 1, '2023-10-24 08:54:16', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (24, 'Botol 330ml', 1, 8, 'btl330', 1, '2023-10-24 08:55:12', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (25, 'Sring Botol 330ml', 1, 8, 'sbt330', 1, '2023-10-24 08:55:46', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (26, 'Tutup Botol 330ml', 1, 8, 'tbt330', 1, '2023-10-24 08:56:13', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (27, 'Kardus Botol 330ml', 1, 8, 'kbt330', 1, '2023-10-24 08:56:51', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (28, 'Botol 500ml', 1, 9, 'btl500', 1, '2023-10-24 08:57:23', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (29, 'Sring Botol 500ml', 1, 9, 'sbt500', 1, '2023-10-24 08:58:37', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (30, 'Sring Botol Amalis 500ml', 1, 10, 'sbta500', 1, '2023-10-24 08:59:12', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (31, 'Tutup Botol 500ml', 1, 9, 'tbt500', 1, '2023-10-24 08:59:53', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (32, 'Kardus Botol 500ml', 1, 9, 'kbt500', 1, '2023-10-24 09:00:23', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (33, 'Botol 1500ml', 1, 11, 'btl1500', 1, '2023-10-24 09:00:47', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (34, 'Kardus Botol 1500ml', 1, 11, 'kbt1500', 1, '2023-10-24 09:01:11', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (35, 'Sring Botol 1500ml', 1, 11, 'sbt1500', 1, '2023-10-24 09:02:19', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (36, 'Sring Botol Amalis 1500ml', 1, 12, 'sbta1500', 1, '2023-10-24 09:03:21', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (37, 'Gelas Maklun', 1, 2, 'gls', 1, '2023-10-24 09:04:28', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (38, 'Guci', 1, 1, 'guc', 1, '2023-10-24 09:04:59', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (39, 'Rak Guci', 1, 1, 'rguc', 1, '2023-10-24 09:05:19', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (40, 'Palet', 1, 1, 'pal', 1, '2023-10-24 09:05:31', 'Dwi Bekti Hariyanto');
INSERT INTO `barang_baku` (`id_barang_baku`, `nama_barang_baku`, `id_satuan`, `id_jenis_barang`, `kode_barang`, `status_barang_baku`, `tgl_input`, `input_barang_baku`) VALUES (41, 'liquid Galon', 1, 1, 'lga', 1, '2023-10-24 09:05:57', 'Dwi Bekti Hariyanto');


#
# TABLE STRUCTURE FOR: barang_jadi
#

DROP TABLE IF EXISTS `barang_jadi`;

CREATE TABLE `barang_jadi` (
  `id_barang_jadi` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_barang` int(11) NOT NULL,
  `jumlah_barang_jadi` int(10) NOT NULL,
  `jumlah_satuan` int(10) NOT NULL,
  `jumlah_liter` float NOT NULL,
  `tanggal_barang_jadi` date NOT NULL,
  `status_barang_produksi` int(1) NOT NULL DEFAULT 1,
  `status_barang_jadi` int(1) NOT NULL DEFAULT 0,
  `input_status_barang_jadi` varchar(50) NOT NULL,
  `tgl_input_barang_jadi` datetime NOT NULL DEFAULT current_timestamp(),
  `tgl_update_barang_jadi` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `bukti_barang_jadi` varchar(50) NOT NULL,
  PRIMARY KEY (`id_barang_jadi`),
  KEY `id_jenis_barang` (`id_jenis_barang`),
  CONSTRAINT `barang_jadi_ibfk_1` FOREIGN KEY (`id_jenis_barang`) REFERENCES `jenis_barang` (`id_jenis_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (1, 1, 132, 132, '2508', '2023-09-01', 1, 0, 'Muh Abd Cholil', '2023-10-25 13:39:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (2, 8, 45, 1080, '356.4', '2023-09-01', 1, 0, 'Muh Abd Cholil', '2023-10-25 13:39:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (3, 9, 32, 768, '384', '2023-09-01', 1, 0, 'Muh Abd Cholil', '2023-10-25 13:39:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (4, 1, 43, 43, '817', '2023-09-02', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:10:55', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (5, 10, 64, 1536, '768', '2023-09-02', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:10:55', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (6, 1, 32, 32, '608', '2023-09-04', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:12:40', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (7, 2, 512, 24576, '112.64', '2023-09-04', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:12:40', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (8, 8, 22, 528, '174.24', '2023-09-04', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:12:40', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (9, 9, 7, 168, '84', '2023-09-04', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:12:40', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (10, 1, 91, 91, '1729', '2023-09-05', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:13:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (11, 2, 430, 20640, '94.6', '2023-09-05', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:13:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (12, 8, 36, 864, '285.12', '2023-09-05', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:13:42', '0000-00-00 00:00:00', '');
INSERT INTO `barang_jadi` (`id_barang_jadi`, `id_jenis_barang`, `jumlah_barang_jadi`, `jumlah_satuan`, `jumlah_liter`, `tanggal_barang_jadi`, `status_barang_produksi`, `status_barang_jadi`, `input_status_barang_jadi`, `tgl_input_barang_jadi`, `tgl_update_barang_jadi`, `bukti_barang_jadi`) VALUES (13, 9, 35, 840, '420', '2023-09-05', 1, 0, 'Muh Abd Cholil', '2023-10-25 14:13:42', '0000-00-00 00:00:00', '');


#
# TABLE STRUCTURE FOR: jenis_barang
#

DROP TABLE IF EXISTS `jenis_barang`;

CREATE TABLE `jenis_barang` (
  `id_jenis_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang_jadi` varchar(100) NOT NULL,
  `jenis_barang` varchar(50) NOT NULL,
  `tgl_input_jenis_barang` datetime NOT NULL DEFAULT current_timestamp(),
  `input_jenis_barang` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jenis_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (1, 'galon 19l', 'galon 19l', '2023-09-30 21:07:23', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (2, 'gelas 220ml ijen', 'gelas 220ml', '2023-09-30 21:07:38', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (3, 'gelas 220ml genggong', 'gelas 220ml', '2023-09-30 21:07:46', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (4, 'gelas 220ml an nujum', 'gelas 220ml', '2023-09-30 21:08:01', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (5, 'gelas 220ml syubbanq', 'gelas 220ml', '2023-09-30 21:08:16', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (6, 'gelas 220ml amalis', 'gelas 220ml', '2023-10-20 08:20:14', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (7, 'gelas 220ml ijen merah', 'gelas 220ml', '2023-10-20 08:20:45', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (8, 'botol 330ml ijen', 'botol 330ml', '2023-10-20 08:20:52', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (9, 'botol 500ml ijen', 'botol 500ml', '2023-10-20 08:21:03', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (10, 'botol 500ml amalis', 'botol 500ml', '2023-10-23 15:11:19', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (11, 'botol 1500 ml ijen', 'botol 1500 ml', '2023-10-23 15:12:14', 'Dwi Bekti Hariyanto');
INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_barang_jadi`, `jenis_barang`, `tgl_input_jenis_barang`, `input_jenis_barang`) VALUES (12, 'botol 1500 ml amalis', 'botol 1500 ml', '2023-10-23 15:12:25', 'Dwi Bekti Hariyanto');


#
# TABLE STRUCTURE FOR: karyawan
#

DROP TABLE IF EXISTS `karyawan`;

CREATE TABLE `karyawan` (
  `id_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_karyawan` varchar(255) NOT NULL,
  `nik_karyawan` varchar(10) NOT NULL,
  `bagian` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `jenkel` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `tgl_input` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (1, 'Suwarna', '01592055', 'Manager', 'Manager', 'Perempuan', 1, '2023-10-16 12:31:17');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (2, 'Muh Abd Cholil', '31119155', 'Produksi', 'Staf', 'Laki-laki', 1, '2023-10-16 12:35:43');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (3, 'Reza Yudianto', '', 'Pemasaran', 'Staf', 'Laki-laki', 1, '2023-10-16 12:36:29');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (4, 'Putra Raga Adityamala', '', 'Keuangan', 'Staf', 'Laki-laki', 1, '2023-10-16 13:01:26');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (5, 'Muhammad Zainul Hasan', '', 'Pemasaran', 'Staf', 'Laki-laki', 1, '2023-10-16 13:01:57');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (6, 'Ardiylla Rosza', '', 'Keuangan', 'Staf', 'Perempuan', 1, '2023-10-16 13:02:25');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (7, 'Dwi Bekti Hariyanto', '', 'Barang Baku', 'Staf', 'Laki-laki', 1, '2023-10-16 13:02:48');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (8, 'Zainul Hasan', '', 'Barang Jadi', 'Staf', 'Laki-laki', 1, '2023-10-16 13:03:10');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (9, 'Ali Shadikin', '', 'Produksi', 'Staf', 'Laki-laki', 1, '2023-10-16 13:04:01');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (10, 'Chinta Adelita Diva', '', 'Keuangan', 'Staf', 'Perempuan', 1, '2023-10-16 13:04:25');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (11, 'Novi Hidayah', '', 'Produksi', 'Staf', 'Laki-laki', 1, '2023-10-16 13:06:54');
INSERT INTO `karyawan` (`id_karyawan`, `nama_karyawan`, `nik_karyawan`, `bagian`, `jabatan`, `jenkel`, `status`, `tgl_input`) VALUES (12, 'Anisah Firdaus', '', 'Pemasaran', 'Staf', 'Perempuan', 1, '2023-10-16 13:07:11');


#
# TABLE STRUCTURE FOR: karyawan_produksi
#

DROP TABLE IF EXISTS `karyawan_produksi`;

CREATE TABLE `karyawan_produksi` (
  `id_karyawan_produksi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_karyawan_produksi` varchar(255) NOT NULL,
  `jenkel` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `tgl_input` datetime NOT NULL DEFAULT current_timestamp(),
  `tgl_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_karyawan_produksi`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (1, 'Moh Haris', 'Laki-laki', 1, '2023-10-18 13:24:45', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (2, 'Juharyanto', 'Laki-laki', 1, '2023-10-18 13:25:44', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (3, 'Dendi S', 'Laki-laki', 1, '2023-10-18 13:27:19', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (4, 'Sumartono', 'Laki-laki', 1, '2023-10-18 13:27:27', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (5, 'Yoga', 'Laki-laki', 1, '2023-10-18 13:27:34', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (6, 'Dio', 'Laki-laki', 1, '2023-10-18 13:27:40', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (7, 'Toni', 'Laki-laki', 1, '2023-10-18 13:27:47', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (8, 'Bagas', 'Laki-laki', 1, '2023-10-18 13:27:56', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (9, 'Andre', 'Laki-laki', 1, '2023-10-18 13:28:04', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (10, 'Anggi', 'Laki-laki', 1, '2023-10-18 13:28:17', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (11, 'Rico', 'Laki-laki', 1, '2023-10-18 13:28:27', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (12, 'Agus', 'Laki-laki', 1, '2023-10-18 13:28:33', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (13, 'Ravi', 'Laki-laki', 1, '2023-10-18 13:28:41', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (14, 'Malik', 'Laki-laki', 1, '2023-10-18 13:28:47', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (15, 'Yudha', 'Laki-laki', 1, '2023-10-18 13:28:54', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (16, 'Novi', 'Laki-laki', 1, '2023-10-18 13:29:11', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (17, 'Imam', 'Laki-laki', 1, '2023-10-18 13:29:17', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (18, 'Temi', 'Laki-laki', 1, '2023-10-18 13:29:25', '0000-00-00 00:00:00');
INSERT INTO `karyawan_produksi` (`id_karyawan_produksi`, `nama_karyawan_produksi`, `jenkel`, `status`, `tgl_input`, `tgl_update`) VALUES (19, 'Zainul Hasan', 'Laki-laki', 1, '2023-10-18 13:29:39', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: keluar_baku
#

DROP TABLE IF EXISTS `keluar_baku`;

CREATE TABLE `keluar_baku` (
  `id_keluar_baku` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_keluar` int(10) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `status_keluar` int(1) NOT NULL DEFAULT 0,
  `status_tolak` int(1) NOT NULL DEFAULT 1,
  `status_produksi` int(1) NOT NULL DEFAULT 1,
  `input_status_keluar` varchar(50) NOT NULL,
  `tgl_input_keluar` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_keluar_gd` varchar(50) NOT NULL,
  PRIMARY KEY (`id_keluar_baku`),
  KEY `id_barang_baku` (`id_barang_baku`),
  CONSTRAINT `keluar_baku_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (1, 8, 400, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:04:49', '2023-09-01.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (2, 4, 1000, '2023-09-04', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:05:32', '2023-09-04.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (3, 7, 96000, '2023-09-04', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:05:55', '2023-09-04.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (4, 10, 500, '2023-09-05', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:08:09', '2023-09-05.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (5, 8, 400, '2023-09-06', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:09:09', '2023-10-06.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (6, 8, 400, '2023-09-07', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:10:10', '2023-09-07.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (7, 7, 96000, '2023-09-11', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:10:51', '2023-09-11.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (8, 6, 144, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:16:13', '2023-09-11.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (9, 8, 240, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:17:52', '2023-09-12.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (10, 10, 200, '2023-09-12', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:18:13', '2023-09-12.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (11, 3, 1000, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:19:20', '2023-09-13.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (12, 7, 96000, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:46:31', '2023-09-13.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (13, 8, 600, '2023-09-13', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:46:50', '2023-09-13.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (14, 8, 500, '2023-09-14', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:47:59', '2023-09-14.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (15, 8, 400, '2023-09-15', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:48:39', '2023-09-15.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (16, 8, 500, '2023-09-18', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:49:36', '2023-09-18.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (17, 10, 500, '2023-09-20', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:50:09', '2023-09-20.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (18, 8, 500, '2023-09-21', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:51:03', '2023-09-21.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (19, 4, 1000, '2023-09-22', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:52:02', '2023-09-22.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (20, 3, 1000, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:55:21', '2023-09-26.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (21, 7, 96000, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:55:48', '2023-09-26.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (22, 8, 500, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:56:16', '2023-09-26.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (23, 10, 500, '2023-09-26', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:56:32', '2023-09-26.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (24, 8, 500, '2023-09-27', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:57:29', '2023-09-27.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (25, 8, 400, '2023-09-28', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:04', '2023-09-28.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (26, 8, 200, '2023-09-29', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:28', '2023-09-29.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (27, 10, 200, '2023-09-29', 1, 1, 1, 'Muh Abd Cholil', '2023-10-05 11:58:44', '2023-09-29.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (57, 11, 200, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:20:18', '2023-09-01.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (58, 24, 1080, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:27:11', '2023-09-01.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (59, 28, 385, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:30:57', '2023-09-01.jpg');
INSERT INTO `keluar_baku` (`id_keluar_baku`, `id_barang_baku`, `jumlah_keluar`, `tanggal_keluar`, `status_keluar`, `status_tolak`, `status_produksi`, `input_status_keluar`, `tgl_input_keluar`, `bukti_keluar_gd`) VALUES (60, 37, 30720, '2023-09-01', 1, 1, 1, 'Muh Abd Cholil', '2023-10-24 10:34:54', '2023-09-01.jpg');


#
# TABLE STRUCTURE FOR: keluar_jadi
#

DROP TABLE IF EXISTS `keluar_jadi`;

CREATE TABLE `keluar_jadi` (
  `id_keluar_jadi` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_barang` int(11) NOT NULL,
  `jumlah_keluar` int(10) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `status_keluar` int(1) NOT NULL DEFAULT 0,
  `status_tolak` int(1) NOT NULL DEFAULT 1,
  `status_produksi` int(1) NOT NULL DEFAULT 1,
  `input_status_keluar` varchar(50) NOT NULL,
  `tgl_input_keluar` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_keluar_gd` varchar(50) NOT NULL,
  PRIMARY KEY (`id_keluar_jadi`),
  KEY `id_barang_baku` (`id_jenis_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: keluar_produksi
#

DROP TABLE IF EXISTS `keluar_produksi`;

CREATE TABLE `keluar_produksi` (
  `id_keluar_produksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_keluar_produksi` int(10) NOT NULL,
  `tanggal_keluar_produksi` date NOT NULL,
  `status_produksi` int(1) NOT NULL DEFAULT 1,
  `input_status_produksi` varchar(50) NOT NULL,
  `tgl_input_produksi` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_keluar_produksi`),
  KEY `id_barang_baku` (`id_barang_baku`),
  CONSTRAINT `keluar_produksi_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: masuk_baku
#

DROP TABLE IF EXISTS `masuk_baku`;

CREATE TABLE `masuk_baku` (
  `id_masuk_baku` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_masuk` int(10) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `status_masuk` int(1) NOT NULL DEFAULT 0,
  `input_status_masuk` varchar(50) NOT NULL,
  `tgl_input_masuk` datetime NOT NULL DEFAULT current_timestamp(),
  `tgl_update_masuk` datetime NOT NULL,
  `bukti_masuk_sj` varchar(50) NOT NULL,
  `bukti_masuk_gd` varchar(100) NOT NULL,
  PRIMARY KEY (`id_masuk_baku`),
  KEY `id_barang_baku` (`id_barang_baku`),
  CONSTRAINT `masuk_baku_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `masuk_baku` (`id_masuk_baku`, `id_barang_baku`, `jumlah_masuk`, `tanggal_masuk`, `status_masuk`, `input_status_masuk`, `tgl_input_masuk`, `tgl_update_masuk`, `bukti_masuk_sj`, `bukti_masuk_gd`) VALUES (1, 6, 144, '2023-09-12', 1, 'Dwi Bekti Hariyanto', '2023-10-05 11:13:17', '2023-10-05 11:13:53', '2023-09-11.jpg', '138327065_756557328312747_5300519839286804070_n.jpg');
INSERT INTO `masuk_baku` (`id_masuk_baku`, `id_barang_baku`, `jumlah_masuk`, `tanggal_masuk`, `status_masuk`, `input_status_masuk`, `tgl_input_masuk`, `tgl_update_masuk`, `bukti_masuk_sj`, `bukti_masuk_gd`) VALUES (2, 7, 1920000, '2023-09-22', 1, 'Dwi Bekti Hariyanto', '2023-10-05 11:53:25', '2023-10-05 11:54:02', '2023-09-22.jpg', '272040805_331086798885295_2032618712761514991_n.jpg');


#
# TABLE STRUCTURE FOR: rusak_baku
#

DROP TABLE IF EXISTS `rusak_baku`;

CREATE TABLE `rusak_baku` (
  `id_rusak_baku` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_rusak_baku` int(10) NOT NULL,
  `tanggal_rusak_baku` date NOT NULL,
  `status_rusak_baku` int(1) NOT NULL DEFAULT 1,
  `input_status_rusak_baku` varchar(50) NOT NULL,
  `tgl_input_rusak_baku` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_rusak_baku` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_rusak_baku`),
  KEY `id_barang_baku` (`id_barang_baku`),
  CONSTRAINT `rusak_baku_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: rusak_jadi
#

DROP TABLE IF EXISTS `rusak_jadi`;

CREATE TABLE `rusak_jadi` (
  `id_rusak_jadi` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_barang` int(11) NOT NULL,
  `jumlah_rusak_jadi` int(10) NOT NULL,
  `tanggal_rusak_jadi` date NOT NULL,
  `status_rusak_baku` int(1) NOT NULL DEFAULT 1,
  `input_status_rusak_jadi` varchar(50) NOT NULL,
  `tgl_input_rusak_jadi` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_rusak_jadi` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_rusak_jadi`),
  KEY `id_barang_baku` (`id_jenis_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: rusak_produksi
#

DROP TABLE IF EXISTS `rusak_produksi`;

CREATE TABLE `rusak_produksi` (
  `id_rusak_produksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_rusak_produksi` int(10) NOT NULL,
  `tanggal_rusak_produksi` date NOT NULL,
  `status_rusak_produksi` int(1) NOT NULL DEFAULT 1,
  `input_status_rusak_produksi` varchar(50) NOT NULL,
  `tgl_input_rusak_produksi` datetime NOT NULL DEFAULT current_timestamp(),
  `bukti_rusak_produksi` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id_rusak_produksi`),
  KEY `id_barang_baku` (`id_barang_baku`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `rusak_produksi` (`id_rusak_produksi`, `id_barang_baku`, `jumlah_rusak_produksi`, `tanggal_rusak_produksi`, `status_rusak_produksi`, `input_status_rusak_produksi`, `tgl_input_rusak_produksi`, `bukti_rusak_produksi`, `keterangan`) VALUES (1, 1, 1, '2023-10-02', 1, 'Muh Abd Cholil', '2023-10-16 09:09:16', '2023-10-02.jpg', 'rusak pada saat produksi');


#
# TABLE STRUCTURE FOR: satuan
#

DROP TABLE IF EXISTS `satuan`;

CREATE TABLE `satuan` (
  `id_satuan` int(11) NOT NULL AUTO_INCREMENT,
  `satuan` varchar(50) NOT NULL,
  `tgl_input_satuan` datetime NOT NULL DEFAULT current_timestamp(),
  `input_satuan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (1, 'pcs', '2023-09-30 21:05:36', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (2, 'meter', '2023-09-30 21:37:05', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (3, 'galon', '2023-09-30 21:37:25', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (4, 'rol', '2023-09-30 21:37:30', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (5, 'dus', '2023-09-30 21:37:45', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (6, 'pak', '2023-10-10 10:57:44', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (7, 'ikat', '2023-10-10 10:57:52', 'Dwi Bekti Hariyanto');
INSERT INTO `satuan` (`id_satuan`, `satuan`, `tgl_input_satuan`, `input_satuan`) VALUES (8, 'sak', '2023-10-10 10:58:08', 'Dwi Bekti Hariyanto');


#
# TABLE STRUCTURE FOR: stok_awal_baku
#

DROP TABLE IF EXISTS `stok_awal_baku`;

CREATE TABLE `stok_awal_baku` (
  `id_stok_awal_baku` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `jumlah_stok_awal_baku` int(10) NOT NULL,
  `tanggal_stok_awal_baku` date NOT NULL,
  `status_stok_awal_baku` int(1) NOT NULL DEFAULT 1,
  `input_status_stok_awal_baku` varchar(50) NOT NULL,
  `tgl_input_stok_awal_baku` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_stok_awal_baku`),
  KEY `id_barang_baku` (`id_barang_baku`),
  CONSTRAINT `stok_awal_baku_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (1, 1, 71, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-09-30 21:30:57');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (2, 3, 64000, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-09-30 21:44:18');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (3, 2, 10000, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-09-30 21:45:01');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (4, 4, 47000, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-03 12:46:58');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (5, 5, 0, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:45:03');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (6, 6, 0, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:45:15');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (7, 7, 2496000, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:45:47');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (8, 8, 21480, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:46:32');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (9, 9, 2800, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:46:47');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (10, 10, 10448, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-05 10:47:01');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (11, 11, 9720, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 08:18:38');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (12, 12, 10140, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 08:43:21');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (13, 13, 9260, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:28:56');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (14, 14, 15, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:29:42');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (15, 15, 16, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:29:58');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (16, 16, 23, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:30:14');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (17, 17, 3, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:30:37');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (18, 18, 16, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:31:02');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (19, 19, 33, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:31:33');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (20, 20, 27, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:31:54');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (21, 21, 20, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:32:17');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (22, 22, 21, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:32:40');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (23, 23, 56, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:32:56');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (24, 24, 57220, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:33:20');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (25, 25, 252347, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:33:37');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (26, 26, 50960, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:34:04');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (27, 27, 1340, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:34:29');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (28, 28, 54439, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:34:43');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (29, 29, 52850, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:35:13');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (30, 30, 0, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:35:36');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (31, 31, 66000, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:35:54');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (32, 32, 12420, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:36:14');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (33, 33, 9008, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:36:32');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (34, 34, 15740, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:36:49');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (35, 35, 146600, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:37:20');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (36, 36, 0, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:39:24');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (37, 37, 234240, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:39:47');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (38, 38, 3, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:39:59');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (39, 39, 2, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:40:10');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (40, 40, 100, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:40:20');
INSERT INTO `stok_awal_baku` (`id_stok_awal_baku`, `id_barang_baku`, `jumlah_stok_awal_baku`, `tanggal_stok_awal_baku`, `status_stok_awal_baku`, `input_status_stok_awal_baku`, `tgl_input_stok_awal_baku`) VALUES (41, 41, 0, '2023-09-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:40:27');


#
# TABLE STRUCTURE FOR: stok_awal_jadi
#

DROP TABLE IF EXISTS `stok_awal_jadi`;

CREATE TABLE `stok_awal_jadi` (
  `id_stok_awal_jadi` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_barang` int(11) NOT NULL,
  `jumlah_stok_awal_jadi` int(10) NOT NULL,
  `tanggal_stok_awal_jadi` date NOT NULL,
  `status_stok_awal_jadi` int(1) NOT NULL DEFAULT 1,
  `input_status_stok_awal_jadi` varchar(50) NOT NULL,
  `tgl_input_stok_awal_jadi` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_stok_awal_jadi`),
  KEY `id_barang_baku` (`id_jenis_barang`),
  KEY `id_jenis_barang` (`id_jenis_barang`),
  CONSTRAINT `stok_awal_jadi_ibfk_1` FOREIGN KEY (`id_jenis_barang`) REFERENCES `jenis_barang` (`id_jenis_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (1, 1, 74, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:15:57');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (2, 2, 1792, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:18:39');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (3, 3, 435, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:19:53');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (4, 4, 154, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:20:10');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (5, 5, 243, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:20:24');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (6, 6, 253, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:20:44');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (7, 7, 400, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:20:55');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (8, 8, 46, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:21:11');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (9, 9, 51, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:21:23');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (10, 10, 52, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:21:35');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (11, 11, 10, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:21:56');
INSERT INTO `stok_awal_jadi` (`id_stok_awal_jadi`, `id_jenis_barang`, `jumlah_stok_awal_jadi`, `tanggal_stok_awal_jadi`, `status_stok_awal_jadi`, `input_status_stok_awal_jadi`, `tgl_input_stok_awal_jadi`) VALUES (12, 12, 45, '2023-09-01', 1, 'Zainul Hasan', '2023-10-26 14:22:08');


#
# TABLE STRUCTURE FOR: stok_minimum
#

DROP TABLE IF EXISTS `stok_minimum`;

CREATE TABLE `stok_minimum` (
  `id_stok_minimum` int(11) NOT NULL AUTO_INCREMENT,
  `id_barang_baku` int(11) NOT NULL,
  `id_satuan` int(10) NOT NULL,
  `isi_stok_minimum` int(10) NOT NULL,
  `jumlah_stok_minimum` int(10) NOT NULL,
  `tanggal_stok_minimum` date NOT NULL,
  `status_stok_minimum` int(1) NOT NULL DEFAULT 1,
  `input_status_stok_minimum` varchar(50) NOT NULL,
  `tgl_input_stok_minimum` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_stok_minimum`),
  KEY `id_barang_baku` (`id_barang_baku`),
  KEY `id_satuan` (`id_satuan`),
  CONSTRAINT `stok_minimum_ibfk_1` FOREIGN KEY (`id_barang_baku`) REFERENCES `barang_baku` (`id_barang_baku`),
  CONSTRAINT `stok_minimum_ibfk_2` FOREIGN KEY (`id_satuan`) REFERENCES `satuan` (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (1, 1, 3, 1, 300, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:23:39');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (2, 2, 1, 100, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:24:40');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (3, 3, 1, 200, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:25:17');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (4, 4, 1, 1000, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:26:01');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (5, 5, 2, 1, 40, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:26:38');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (6, 6, 5, 1, 36, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:27:30');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (7, 7, 1, 96000, 134, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:28:10');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (8, 8, 1, 20, 500, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:28:52');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (9, 9, 1, 20, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:29:34');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (10, 10, 1, 20, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-10 12:29:53');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (11, 11, 1, 20, 300, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 08:25:16');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (12, 12, 1, 20, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 08:44:43');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (13, 13, 1, 20, 300, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:07:56');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (14, 14, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:08:52');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (15, 15, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:09:34');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (16, 16, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:10:05');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (17, 17, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:10:41');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (18, 18, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:11:45');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (19, 19, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:11:45');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (20, 20, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:12:13');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (21, 21, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:12:32');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (22, 22, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:13:00');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (23, 23, 1, 1, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:14:47');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (24, 24, 1, 108, 120, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:15:44');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (25, 25, 1, 250, 180, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:16:45');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (26, 26, 1, 6000, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:17:16');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (27, 27, 1, 20, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:17:39');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (28, 28, 1, 100, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:18:02');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (29, 29, 1, 250, 180, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:18:25');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (30, 30, 1, 1, 400, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:19:29');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (31, 31, 1, 2500, 20, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:20:00');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (32, 32, 1, 20, 40, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:20:35');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (33, 33, 1, 50, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:20:52');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (34, 34, 1, 20, 80, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:21:08');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (35, 35, 1, 200, 80, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:21:28');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (36, 36, 1, 0, 80, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:21:47');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (37, 37, 1, 3840, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:22:08');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (38, 38, 1, 1, 4, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:22:27');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (39, 39, 1, 1, 3, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:22:44');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (40, 40, 1, 1, 100, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:23:13');
INSERT INTO `stok_minimum` (`id_stok_minimum`, `id_barang_baku`, `id_satuan`, `isi_stok_minimum`, `jumlah_stok_minimum`, `tanggal_stok_minimum`, `status_stok_minimum`, `input_status_stok_minimum`, `tgl_input_stok_minimum`) VALUES (41, 41, 1, 0, 0, '2023-01-01', 1, 'Dwi Bekti Hariyanto', '2023-10-24 09:23:41');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengguna` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `nik_karyawan` varchar(10) NOT NULL,
  `upk_bagian` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `level` varchar(50) NOT NULL DEFAULT 'Pengguna',
  `status` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (2, 'administrator', 'Dicky Erfan Septiono', '', 'dicky', '$2y$10$MFzEk5qSvSQo1l8Ip4Psaelp4bi20s9Fwus8n3I0J5tien9xdao8G', 'Admin', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (18, 'Manager', 'Suwarna', '01592055', 'admin', '$2y$10$rlcKUpdaS8gX9cYZO1OwveUlifZyAB8V3qStlq16chvl85RjqYOOm', 'Admin', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (23, 'Barang Baku', 'Dwi Bekti Hariyanto', '', 'baku', '$2y$10$SrOVe0nXrG2ERB7SWwBKX.dRZTPkPHWKih8DWW89whqAT2BGywnje', 'Pengguna', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (24, 'Barang Produksi', 'Muh Abd Cholil', '', 'produksi', '$2y$10$m1cIFZkeGC3JSe1L0Rin1eM17ot2aiLWrRy6bTkVv7capXALepI3u', 'Pengguna', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (25, 'Barang Jadi', 'Zainul Hasan', '', 'jadi', '$2y$10$wA3JxLnd1utg.xmRyXf6rea9GRCD2nmSsWViwQi4f3adR5VRvFUGq', 'Pengguna', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (26, 'Pemasaran', 'Reza Yudianto', '', 'pasar', '$2y$10$tXTj7SZFfvn09qJwQK0zs.4hJzOI/CcBtvwUXVA3W61QqZYAQyc3i', 'Pengguna', 1);
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `nik_karyawan`, `upk_bagian`, `password`, `level`, `status`) VALUES (51, 'Keuangan', 'Ardiylla Rosza', '', 'uang', '$2y$10$ZnJTXVo5Nw5tg.oMYy7CX.4aoBdIj6VleM/c0X1mKW7bVLNTrhRb2', 'Pengguna', 1);


